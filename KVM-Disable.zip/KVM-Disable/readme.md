# Skript ist dafür dass der KVM Deaktiviert wird und zwar permanent.
# Das hilft als beispiel beim Virtual Box.
# Intel ist für Intel Prozessoren
# AMD für AMD Prozessoren
